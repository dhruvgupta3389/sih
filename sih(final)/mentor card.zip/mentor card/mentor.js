// Function to filter mentors by subject
function filterBySubject() {
    const selectedSubject = document.getElementById('subjectFilter').value;
    const profiles = document.querySelectorAll('.profile');

    profiles.forEach(profile => {
        const subject = profile.getAttribute('data-subject');

        if (selectedSubject === 'all' || subject === selectedSubject) {
            profile.classList.remove('hidden');
        } else {
            profile.classList.add('hidden');
        }
    });
}

// Function to filter mentors by name
function filterByName() {
    const searchQuery = document.getElementById('searchBar').value.toLowerCase();
    const profiles = document.querySelectorAll('.profile');

    profiles.forEach(profile => {
        const name = profile.querySelector('h2').innerText.toLowerCase();

        if (name.includes(searchQuery)) {
            profile.classList.remove('hidden');
        } else {
            profile.classList.add('hidden');
        }
    });
}
